package com.example.practica1android

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class OrdenViewModel : ViewModel() {

    private val _orden : MutableList<String> = mutableListOf("So orden" )

    //private val _orden = MutableLiveData<MutableList<String>>()
    //val orden : LiveData<MutableList<String>> get() = _orden

    init {
        Log.i("OrdenViewModel", "Se ha creado un OrdenViewModel")
    }


    override fun onCleared() {
        super.onCleared()
        Log.i("OrdenViewModel", "Se ha destrudo el objeto OrdenViewModel")
    }

    fun addOrden(string: String) {
        _orden.add(string)
        //_orden.value?.add(string)
        //Log.i("OrdenViewModel", "Se agrego una orden" + orden.value)
    }

    fun getOrden(): List<String>? {
        return _orden
    }
}
