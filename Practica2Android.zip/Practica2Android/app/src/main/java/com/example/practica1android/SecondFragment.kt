package com.example.practica1android

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import com.example.practica1android.databinding.FragmentSecondBinding

/**
 * A simple [Fragment] subclass as the second destination in the navigation.
 */
class SecondFragment : Fragment() {

    val _orden : MutableList<String> = mutableListOf("Su orden" )
    private var _binding: FragmentSecondBinding? = null
    private lateinit var viewModel: SecondFragmentViewModel
   private lateinit var viewModelFactory: SecondFragmentViewModelFactory

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
            inflater: LayoutInflater, container: ViewGroup?,
            savedInstanceState: Bundle?
    ): View? {

            viewModelFactory = SecondFragmentViewModelFactory(SecondFragmentArgs.fromBundle(requireArguments()).orden)
          viewModel = ViewModelProvider(this, viewModelFactory).get(SecondFragmentViewModel::class.java)
        _binding = FragmentSecondBinding.inflate(inflater, container, false)
        return binding.root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        //viewModel.getOrden()
        //viewModel.getOrden()
        binding.buttonSecond.setOnClickListener {
            findNavController().navigate(R.id.action_SecondFragment_to_FirstFragment)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}