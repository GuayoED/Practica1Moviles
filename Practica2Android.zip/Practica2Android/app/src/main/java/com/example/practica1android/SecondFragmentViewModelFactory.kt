package com.example.practica1android

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider

class SecondFragmentViewModelFactory(private val ordenA: Array<String>): ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(SecondFragmentViewModel::class.java)) {
            return SecondFragmentViewModel(ordenA) as T
        }
        throw IllegalArgumentException("Unknow ViewModel class")
    }
}