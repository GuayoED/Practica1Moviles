package com.example.practica1android

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider

class SecondFragmentViewModel(ordenA: Array<String>) : ViewModel() {
   val _orden = MutableLiveData<List<String>>()
    val orden : LiveData<List<String>> get() = _orden
  // val _orden : MutableList<String> = mutableListOf("Su orden" )
   // var _orden = ordenA

    init {
        _orden.value = ordenA.toList()
        Log.i("SecondFragmentViewModel", "Final array is...")
        for (i in ordenA){
            Log.i("SecondFragmentViewModel", "$ordenA")
        }
    }
    fun getOrden(): List<String>? {
        Log.i("SecondFragmentViewModel", "El pedido" + orden.value)
        return orden.value

     //   return _orden
    }
}

